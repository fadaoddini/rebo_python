from django.contrib import admin

from login.models import MyUser

admin.site.register(MyUser)
